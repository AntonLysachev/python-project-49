### Hexlet tests and linter status:
[![Actions Status](https://github.com/AntonLysachev/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/AntonLysachev/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/75f94e09cbcde3ded791/maintainability)](https://codeclimate.com/github/AntonLysachev/python-project-49/maintainability)